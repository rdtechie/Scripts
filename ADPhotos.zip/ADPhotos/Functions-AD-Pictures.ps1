﻿#requires -Version 2
Function Get-ADThumbnailPhoto() {
    <#
            .Synopsis
            Get Active Directory user thumbnail image
            .Description
            Extracts the current user thumbnail image from active directory
            .Parameter UserName
            The username of the person you're looking for
            .Parameter Path
            The path for the file you would like to output to, i.e. c:\test.jpg
            .Example
            Get-ADThumbnailPhoto -UserName PeterRossi -Path c:\PeterRossi.JPG
 
            This will extract the thumbnail image for user PeterRossi and export it to c:\PeterRossi.jpg
            .Notes
            Name: Get-ADThumbnailPhoto
            Author: Peter Rossi
            Last Edited: 13th May 2011
    #>
    param(
        [Parameter(Mandatory = $True, Position = 0, ValueFromPipeline = $False)]
        [string[]]$UserName,
        [Parameter(Mandatory = $True, ValueFromPipeline = $False)]
        [String]$Path
    )
    $ADSearcher = New-Object -TypeName DirectoryServices.DirectorySearcher -ArgumentList ("(&(SAMAccountName=$UserName))")
    $Users = $ADSearcher.FindOne()
 
    if($Users -ne $null)
    {
        [adsi]$TheUser = "$($Users.Path)"
        $Thumbnail = $TheUser.ThumbnailPhoto.Value
        [System.IO.File]::WriteAllBytes($Path,$Thumbnail)	
    }
    Else
    {Write-Warning -Message "User $UserName could not be found in AD, is it the right username?"}
}
 
Function Set-ADThumbnailPhoto(){
    <#
            .Synopsis
            Set Active Directory user thumbnail image
            .Description
            Sets the current user thumbnail image from active directory
            .Parameter UserName
            The username of the person you're looking for
            .Parameter JPGPath
            The path for the file you would like to use as the new thumbnail
            .Example
            Set-ADThumbnailPhoto -UserName PeterRossi -JPGPath c:\PeterRossi.JPG
 
            This will set the thumbnail image for user PeterRossi using c:\PeterRossi.jpg
            .Notes
            Name: Set-ADThumbnailPhoto
            Author: Peter Rossi
            Last Edited: 13th May 2011
    #>
    param(
        [Parameter(Mandatory = $True, Position = 0, ValueFromPipeline = $False)]
        [string[]]$UserName,
        [Parameter(Mandatory = $True, ValueFromPipeline = $False)]
        [String]$JPGPath
    )
 
    if((Test-Path $JPGPath) -eq $True)
    {
        [byte[]]$Thumbnail = Get-Content $JPGPath -Encoding byte
 
        $ADSearcher = New-Object -TypeName DirectoryServices.DirectorySearcher -ArgumentList ("(&(SAMAccountName=$UserName))")
        $UserSearch = $ADSearcher.FindOne()
 
        if($UserSearch -ne $null)
        {
            $User = [ADSI]"$($UserSearch.Path)"
            $User.put('thumbnailPhoto',  $Thumbnail )
            $User.setinfo()
        }
        Else
        {Write-Warning -Message "User $UserName could not be found in AD, is it the right username?"}
    }
    Else
    {Write-Warning -Message "Can't find $JPGPath, does it exist?"}
}
