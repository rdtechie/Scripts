﻿#requires -Version 1
#requires -Modules ActiveDirectory

$inputFolder 		= '\\Server\Share\EmailPhoto\'
$outputFolder 		= 'C:\Users\Public\Scripts\ADPhotos\Output\'
$convertedFolder 	= 'C:\Users\Public\Scripts\ADPhotos\Converted\'
$scriptLocation 	= 'C:\Users\Public\Scripts\ADPhotos\'
$pictures 			= Get-ChildItem $inputFolder

Set-Location $scriptLocation
.\Convert-ProfilePictures.ps1 -InputFolder $inputFolder -OutputFolder $outputFolder

foreach ($picture in $pictures){
    $user 				= Get-ADUser -Filter "EmployeeID -eq $($picture.BaseName)" -Properties SAMAccountName
    $pictureName 		= $picture.Name
    $pictureLength 		= $pictureName.Length
    $convertedPicture 	= $outputFolder + ($pictureName.Substring(0,$pictureLength-3)) + 'jpg'

    Copy-Item -Path $convertedPicture -Destination $convertedFolder

    $pictureContent = [byte[]](Get-Content -Path $convertedFolder\* -Encoding byte)
    $user | Set-ADUser -Replace @{
        thumbnailPhoto = $pictureContent
    }

    Start-Sleep -Seconds 5 

    Get-ChildItem $convertedFolder | Remove-Item -Confirm:$false
}

Remove-Item -Path $inputFolder\* -Recurse
Remove-Item -Path $outputFolder\* -Recurse