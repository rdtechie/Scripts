﻿$InputFolder = "\\Server\Share\Email Photo\"
$OutputFolder = "C:\Users\Public\Scripts\ADPhotos\Output\"
$ConvertedFolder = "C:\Users\Public\Scripts\ADPhotos\Converted\"
$ScriptLocation = "C:\Users\Public\Scripts\ADPhotos\"

Add-PSSnapin Quest.ActiveRoles.ADManagement


$Date = Get-Date -Format o | foreach {$_ -replace ":", "."}
$Pictures = Get-ChildItem $InputFolder

Set-Location $ScriptLocation
.\GALBatchConvert.ps1 -InputFolder $InputFolder -OutputFolder $OutputFolder


foreach ($Picture in $Pictures){

$User =  $Picture | Get-Acl | select Owner -ExpandProperty Owner
$PictureName = $Picture.Name
$PictureLength = $PictureName.Length
$ConvertedPicture = $OutputFolder + ($PictureName.Substring(0,$PictureLength-3)) + "jpg"

Copy-Item -Path $ConvertedPicture -Destination $ConvertedFolder


$PictureContent = [byte[]](Get-Content $ConvertedFolder\*  -Encoding byte)
Get-QADuser $User | Set-QADUser -ObjectAttributes @{thumbnailPhoto=$PictureContent} | out-file ".\logs\log$date.txt" -Append

sleep 5 

get-childitem $ConvertedFolder | Remove-Item
}

Remove-Item $InputFolder\* -Recurse
Remove-Item $OutputFolder\* -Recurse